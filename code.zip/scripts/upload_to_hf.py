import os
from huggingface_hub import HfApi, upload_folder

# Set environment variables
os.environ["WANDB_DISABLED"] = "true"
os.environ['HF_TOKEN'] = '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'

# Save your token to the cache
token = os.environ['HF_TOKEN']

# Initialize the API
api = HfApi()

# Define the local folder path and the repo_id
model_folder = '/home/tushar/vscode/TheComicFusion/manga_ocr_dev/assets/ko_synthetic'
repo_id = 'Tushar01/Korean-OCR'  # Replace with your username and repo name

# Upload the folder contents to the Hugging Face Hub
upload_folder(
    folder_path=model_folder,
    repo_id=repo_id,
    repo_type="dataset",
    token=token,
)
