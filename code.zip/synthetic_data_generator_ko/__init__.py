"""
Korean synthetic data generator package.

This module provides a simplified, language-agnostic pipeline for generating
synthetic image–text pairs for Korean text. It intentionally avoids all
Japanese-specific constructs used in the original `synthetic_data_generator`
package (no Japanese tokenization, furigana, or kanji/hiragana/katakana logic).
"""


